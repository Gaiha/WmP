package com.example.frida.wmp;

/**
 * Created by Frida on 2014-09-24.
 */
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //DatabaseController dbController = new DatabaseController(this);

        changeFragments(new FragmentPG1());
    }

    /**
     *
     * @param fragment
     */
    public void changeFragments(Fragment fragment) {
        FragmentTransaction fm = getFragmentManager().beginTransaction();

        fm.replace(R.id.upper_container, fragment);
        fm.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R .menu.main, menu);
        return true;
    }

}
